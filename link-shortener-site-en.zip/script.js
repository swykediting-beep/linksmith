// Dom helpers
const $ = (q, el=document) => el.querySelector(q);
const $$ = (q, el=document) => [...el.querySelectorAll(q)];
const esc = (s) => s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));

// Input parsing
function parseInput(text){
  return [...new Set(text.split(/\r?\n/).map(s => s.trim()).filter(Boolean))];
}

// Busy state
function setBusy(b){
  $('#shortenBtn').disabled = b;
  $('#clearBtn').disabled = b;
  $('#shortenBtn').ariaBusy = String(b);
}

// Toast
let toastTimer;
function toast(msg){
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=> el.classList.remove('show'), 1800);
}

// Shortening services
async function shortenWithTinyURL(url){
  const resp = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`);
  const txt = await resp.text();
  if(!resp.ok || !/^https?:\/\//.test(txt)) throw new Error((txt||'TinyURL error').slice(0,120));
  return txt.trim();
}

async function shortenWithIsGd(url){
  const resp = await fetch(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(url)}`);
  const txt = await resp.text();
  if(!resp.ok || txt.toLowerCase().includes('error:')) throw new Error((txt||'is.gd error').slice(0,120));
  return txt.trim();
}

async function shortenWithVGd(url){
  const resp = await fetch(`https://v.gd/create.php?format=simple&url=${encodeURIComponent(url)}`);
  const txt = await resp.text();
  if(!resp.ok || txt.toLowerCase().includes('error:')) throw new Error((txt||'v.gd error').slice(0,120));
  return txt.trim();
}

async function shortenWithShrtco(url){
  const resp = await fetch(`https://api.shrtco.de/v2/shorten?url=${encodeURIComponent(url)}`);
  const data = await resp.json();
  if(!resp.ok || data.ok === false) throw new Error((data.error||'shrtco error').slice(0,120));
  return data.result.full_short_link;
}

const services = {
  tinyurl: { name: 'TinyURL', fn: shortenWithTinyURL },
  isgd:   { name: 'is.gd', fn: shortenWithIsGd },
  vgd:    { name: 'v.gd',  fn: shortenWithVGd },
  shrtco: { name: 'shrtco.de', fn: shortenWithShrtco },
};

// Rendering
function renderRows(urls){
  const tbody = $('#resultTable tbody');
  tbody.innerHTML = '';
  urls.forEach((u, i) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${i+1}</td>
      <td><a target="_blank" rel="noopener noreferrer" href="${esc(u)}">${esc(u)}</a></td>
      <td class="tinyurl small">–</td>
      <td class="isgd small">–</td>
      <td class="vgd small">–</td>
      <td class="shrtco small">–</td>
    `;
    tbody.appendChild(tr);
  });
}

// Status + progress
function updateStatus(done, total, svcName){
  $('#status').textContent = `Processing with ${svcName}… ${done}/${total}`;
  const pct = total ? Math.round((done/total)*100) : 0;
  $('#progressBar').style.width = pct + '%';
}

// Copy button
function addLinkToCell(cell, shortUrl){
  cell.innerHTML = '';
  const a = document.createElement('a');
  a.href = shortUrl;
  a.target = '_blank';
  a.rel = 'noopener noreferrer';
  a.textContent = shortUrl;
  const btn = document.createElement('button');
  btn.className = 'copy';
  btn.textContent = 'Copy';
  btn.addEventListener('click', async () => {
    try{
      await navigator.clipboard.writeText(shortUrl);
      toast('Short link copied');
    }catch{
      toast('Copy failed');
    }
  });
  cell.appendChild(a);
  cell.appendChild(btn);
}

// Main
async function run(){
  const urls = parseInput($('#urls').value);
  if(urls.length === 0){ $('#status').textContent = 'Please paste some links first.'; return; }

  const enabledSvcs = $$('.svc:checked').map(i => i.value);
  if(enabledSvcs.length === 0){ $('#status').textContent = 'Please select at least one service.'; return; }

  renderRows(urls);
  setBusy(true);
  $('#progressBar').style.width = '0%';
  $('#status').textContent = '';

  for(const svcKey of enabledSvcs){
    const svc = services[svcKey];
    let done = 0;
    updateStatus(done, urls.length, svc.name);
    for(let row=0; row<urls.length; row++){
      const url = urls[row];
      const cell = $('#resultTable tbody').rows[row].querySelector('.' + svcKey);
      try{
        const shortUrl = await svc.fn(url);
        addLinkToCell(cell, shortUrl);
      }catch(e){
        const msg = (e && e.message) ? String(e.message) : 'Error';
        cell.innerHTML = `<span style="color:var(--err)" title="${msg}">Error</span>`;
      }
      done++;
      updateStatus(done, urls.length, svc.name);
    }
    // subtle reset between services for progress bar
    $('#progressBar').style.width = '0%';
  }

  $('#status').textContent = 'Done.';
  setBusy(false);
}

$('#shortenBtn').addEventListener('click', run);
$('#clearBtn').addEventListener('click', () => {
  $('#urls').value = '';
  $('#resultTable tbody').innerHTML = '';
  $('#status').textContent = '';
  $('#progressBar').style.width = '0%';
});
